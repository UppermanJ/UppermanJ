Program:  ProgrammingAssignment3.cpp
Author:  JS Upperman
Input File:  customers.txt

Execute in Dev-C++:  Open ProgrammingAssignment3.cpp
                     Select Compile and Run
                     When program asks for file name, enter:  customers // It will concatenate the ".txt" on its own
                     
Execute stand alone: ProgramExample 1997     // This is not REQUIRED ** I was not sure what this line was indicating
                                                 to the user so i could not figure out how I should alter it


