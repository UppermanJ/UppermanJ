Program:  ProgrammingAssignment4.cpp
Author:  JS Upperman
Input File:  FootballData.txt

Execute in Dev-C++:  Open ProgrammingAssignment4.cpp
                     Select Compile and Run
                     When program asks for file name, enter:  FootballData.txt
                     


